B41M14 — Kahoot: οδηγίες καθηγητή

Εισαγωγή: Kahoot → Create → Add question → Import → Import spreadsheet. Επιλέξτε το αντίστοιχο XLSX.
4 standard Quiz questions. Μία σωστή απάντηση ανά ερώτηση. Χωρίς premium τύπους ερωτήσεων.
Εικόνες: προσθέστε χειροκίνητα a στην ερώτηση 1, b στη 2, c στη 3 και d στη 4.
Οι εικόνες είναι πραγματικά παραδείγματα/στιγμιότυπα Microsoft Support. Οι εκδόσεις του Excel μπορεί να διαφέρουν από το βιβλίο.
Δεν απαιτείται η εικόνα για την απάντηση. Η αρχική επισήμανση εντολών της Microsoft μπορεί να δίνει οπτική βοήθεια.
Η τετράδα είναι σύντομος διαγνωστικός έλεγχος επιλεγμένων βασικών στόχων, όχι πλήρης πρακτική αξιολόγηση όλου του κεφαλαίου.

1. Θέλεις τίτλο με Bold και 16 pt, χωρίς να αλλάξει το Legend. Τι επιλέγεις πρώτα;
Σωστή απάντηση: 4 — Chart Title
Δείκτης Επιτυχίας: Β4.5.4, Β4.5.5 | Δείκτης Επάρκειας: Β4.5.4
Επιλογή Chart Title πριν από αλλαγή Bold και Font Size.
Εικόνα: B41M14-a.png
Πηγή σελίδας: https://support.microsoft.com/en-us/office/excelexp/add-or-remove-titles-in-a-chart
Αρχική εικόνα: https://support.microsoft.com/en-us/office/media/70ecaacb-d243-4a4d-91d6-113af878f290.gif

2. Σε Pie θέλεις ποσοστά έξω από τα τμήματα. Ποιος συνδυασμός Data Labels ταιριάζει;
Σωστή απάντηση: 2 — Percentage + Outside End
Δείκτης Επιτυχίας: Β4.5.4 | Δείκτης Επάρκειας: Β4.5.4
Data Labels: Percentage και Outside End.
Εικόνα: B41M14-b.png
Πηγή σελίδας: https://support.microsoft.com/en-us/office/change-the-format-of-data-labels-in-a-chart
Αρχική εικόνα: https://support.microsoft.com/en-us/office/media/ogv15piepercentlabels.jpg

3. Θέλεις κόκκινες ΟΛΕΣ τις στήλες του 2016, μόνο αυτές. Τι μορφοποιείς;
Σωστή απάντηση: 1 — Τη Data Series του 2016
Δείκτης Επιτυχίας: Β4.5.5 | Δείκτης Επάρκειας: Β4.5.4
Data Series: αλλάζει όλη η σειρά του 2016. Data Point: μόνο μία στήλη.
Εικόνα: B41M14-c.png
Πηγή σελίδας: https://support.microsoft.com/en-us/office/format-elements-of-a-chart
Αρχική εικόνα: https://support.microsoft.com/en-us/office/media/office-2016-chart-tools-shape-fill-menu.png

4. Θέλεις φόντο Chart Area κίτρινο και Legend δεξιά με λευκό φόντο. Τι κάνεις;
Σωστή απάντηση: 3 — Κίτρινο Chart Area, Legend Right με λευκό Fill
Δείκτης Επιτυχίας: Β4.5.4, Β4.5.5 | Δείκτης Επάρκειας: Β4.5.4
Chart Area κίτρινο. Legend Right, και ξεχωριστή αλλαγή Fill του Legend σε λευκό.
Εικόνα: B41M14-d.png
Πηγή σελίδας: https://support.microsoft.com/en-us/excel/add-and-format-a-chart-legend
Αρχική εικόνα: https://support.microsoft.com/en-us/excel/media/xl16formatlegendclosedarrow.png

Βιβλίο: Πληροφορική Β΄ Γυμνασίου — Τετράδιο Εργασιών, Β.4.1.Μ14, σ. 51–52.
Επίσημοι δείκτες (Β΄ Γυμνασίου, ενότητα 4, έντυπες σ. 19–21): https://www.moec.gov.cy/analytika_programmata/deiktes_epitychias_eparkeias/dee_gym_pliroforiki.pdf
Kahoot import: https://support.kahoot.com/hc/en-us/articles/115002812547
Οι εικόνες ανήκουν στη Microsoft. Διατηρούνται οι σύνδεσμοι προέλευσης.