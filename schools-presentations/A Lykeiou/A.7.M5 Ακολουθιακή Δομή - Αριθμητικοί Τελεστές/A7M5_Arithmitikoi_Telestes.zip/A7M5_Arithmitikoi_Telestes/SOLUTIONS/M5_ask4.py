# M5_ask4.py · Λύση / Solution
# Επιπρόσθετη 1: ⭐ Απόσταση δύο σημείων
# Παράδειγμα / Example: 1, 2, 4, 6 → 5

x1 = float(input('x1: '))
y1 = float(input('y1: '))
x2 = float(input('x2: '))
y2 = float(input('y2: '))
d = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
print('Απόσταση AB:', d)
